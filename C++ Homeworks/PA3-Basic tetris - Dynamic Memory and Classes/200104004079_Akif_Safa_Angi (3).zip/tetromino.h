#ifndef TETROMINO_H
#define TETROMINO_H

#include <iostream>
#include <unistd.h>
#include <limits>

namespace TetrisSpace
{
   enum class tetrominos {I,O,T,J,L,S,Z}; //Create strong enum

   class Tetromino {
      private:
         char shapeLetter;
         char **shape = NULL;
         int **shapePos = NULL;
      public:
         Tetromino(const tetrominos &s);//Constructor
         ~Tetromino();
         void Print();//Print the shape
         void Rotate(const char &rotation);//rotate the shape
         void fixShape();//set shape to left corner
         bool canFit(Tetromino &other,int **pos);//check if the blocks fit each other
         char** GetShape();
         int** GetShapePos();
         friend class Tetris;
   };
}
#endif