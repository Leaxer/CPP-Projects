#include "tetromino.h"
#include "tetris.h"

using namespace TetrisSpace;

int main()
{
   Tetromino *tetromin = new Tetromino(tetrominos::T);
   Tetris tetrisGame(20,20);
   tetrisGame += tetromin;
   tetrisGame.Animate(0, tetromin);
   delete tetromin;
   std::cout << "\033["<< 21 <<"A\033[0G\033[2K";
   std::cout << "\033[J";
   return 0;
}